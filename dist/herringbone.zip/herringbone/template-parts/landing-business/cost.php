<?php


/**
 * Herringbone Theme Template Part - Dev Landing Page - Cost Section.
 *
 * @package herringbone
 * @author Jefferson Real <me@jeffersonreal.uk>
 * @copyright Copyright (c) 2022, Jefferson Real
 */
?>

<div class="landing_content " style="--row: 1 / -1; --col: narrow-l / narrow-r;">

	<div class="copy">
		<h2>This is how much a website costs</h2>
		<p>Placeholder for website pricing</p>
	</div>

</div>

<div class="landing_backdrop">
</div>
